import asyncio
from bot import start_zombiebot

if __name__ == "__main__":
    asyncio.run(start_zombiebot())
